require 'test_helper'

class SesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
