require 'test_helper'

class ViewallemployeesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
