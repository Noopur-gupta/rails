require 'test_helper'

class AdminWorkHelperTest < ActionView::TestCase
end
