require 'test_helper'

class SesHelperTest < ActionView::TestCase
end
