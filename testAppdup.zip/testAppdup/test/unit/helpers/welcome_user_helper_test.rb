require 'test_helper'

class WelcomeUserHelperTest < ActionView::TestCase
end
