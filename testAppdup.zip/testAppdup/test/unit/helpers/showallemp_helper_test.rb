require 'test_helper'

class ShowallempHelperTest < ActionView::TestCase
end
