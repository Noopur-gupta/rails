require 'test_helper'

class ViewallemployeesHelperTest < ActionView::TestCase
end
