class Project < ActiveRecord::Base
  attr_accessible :end_date, :location, :name, :start_date, :user_id
	
belongs_to :user
	
validates :name, presence: true, length: { maximum: 30 } ,:format => { :with => /^[A-Za-z]+$/ } 
validates :location, presence: true, length: { maximum: 30 } ,:format => { :with => /^[A-Za-z]+$/ } 

end
