class WelcomeUserController < ApplicationController

end
