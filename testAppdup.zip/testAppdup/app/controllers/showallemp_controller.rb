class ShowallempController < ApplicationController
  def index
  end
end
