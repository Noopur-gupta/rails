class ViewallemployeesController < ApplicationController
def index

end
end
