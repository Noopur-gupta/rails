class ProjectsController < ApplicationController
  # GET /projects
  # GET /projects.json
  def index
    @projects = Project.order(:name)
   @projects = Project.paginate page: params[:page],
      per_page: 6
  
    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @projects }
    end
  end

  # GET /projects/1
  # GET /projects/1.json
  def show
    @project = Project.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @project }
    end
  end

  # GET /projects/new
  # GET /projects/new.json
  def new
    @project = Project.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @project }
    end
  end

  # GET /projects/1/edit
  def edit
    @project = Project.find(params[:id])
  end

  # POST /projects
  # POST /projects.json
  def create
  
    @project = Project.new(params[:project])
    flag =0
    t=1
    @user=User.all
     @user.each do |user|
    
      if (user.id == @project.user_id) 
         flag=1
         break
      elsif @project.user_id == nil
         flag=2
         break
      end
      end
	if flag==2
           
              respond_to do |format|
                  if @project.save
	            if @project.update_attributes(params[:project])
                            
                           format.html { redirect_to @project, notice: 'Project was successfully created.' }
                           format.json { render json: @project, status: :created, location: @project }
                    else
                           format.html { render action: "new" }
                           format.json { render json: @project.errors, status: :unprocessable_entity }
                    end
                  end
                end
	
         elsif flag==1
   
        @user=(User.where(id: params[:project][:user_id]))[0]
	pro_name=@user.project_name
	pro_id=  @user.project_id
        respond_to do |format|
	        if @project.save
	            if @project.update_attributes(params[:project])
	                  if @user.project_name == nil
	                     @user.update_attribute(:project_name,@project.name)		
		                 @user.update_attribute(:project_id,@project.id)
	                   else
					   	 arr=Array.new
				          
                          arr=pro_name.split(", ")
						  
						  
                          arr.each do |i|
                           if(i == @project.name)
						     @user.update_attribute(:project_name,pro_name)
							 @user.update_attribute(:project_id,pro_id)
							 t=2
							 break
                            
		                    end
                     		end
						  if t==1				   
						 @user.update_attribute(:project_name,pro_name + ", " + @project.name)
							
			              end
						  end

	                   
                    if(t==2)
                    format.html { redirect_to new_project_path, notice: 'Project already exist.' }
                    @project.destroy
               
                    
                     else
	            format.html { redirect_to @project, notice: 'Project was successfully created.' }
                    format.json { render json: @project, status: :created, location: @project }
                    end
	       else
                format.html { render action: "new" }
                format.json { render json: @project.errors, status: :unprocessable_entity }
                end
            end
        end
   else
      redirect_to new_project_path, notice: 'User Id not present. Please refer View employees list'
   end
 end

  # PUT /projects/1
  # PUT /projects/1.json
  def update
        arr=Array.new
	@project = Project.find(params[:id])
    
	@user=(User.where(id: params[:project][:user_id]))[0]
	
	pro_name=@user.project_name
    
	t=1
	respond_to do |format|
          if @project.update_attributes(params[:project])
		      
	           if @user.project_name == nil
			   
	              @user.update_attribute(:project_name,@project.name)	
                else		
                  			
		                  arr=Array.new
				  
                          arr=pro_name.split(", ")
						  
                          arr.each do |i|
                           if(i == @project.name)
						     @user.update_attribute(:project_name,pro_name)
							 t=2
							 break
                            
		                    end
                     		end
			    if t==1				   
						    @user.update_attribute(:project_name,pro_name + ", " + @project.name)
			    end
		end
				
      		   
	    format.html { redirect_to @project, notice: 'Project was successfully updated.' }
            format.json { head :no_content }
               

	  else
        format.html { render action: "edit" }
        format.json { render json: @project.errors, status: :unprocessable_entity }
      end
  end
  end
  
=begin
       respond_to do |format|
        if @project.update_attributes(params[:project])
            
         
       if(@user.project_name=="")				
	    	@user.update_attribute(:project_id=>@project.id)
         else
					
	#render text: @user.project_name
	@user.project_id=@project.id
        #render text: @user.project_name
	@user.project_name= pro_name +"," + @project.name
         end

	

       format.html { redirect_to @project, notice: 'Project was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @project.errors, status: :unprocessable_entity }
      end

    
     end    
=end


  # DELETE /projects/1
  # DELETE /projects/1.json
def destroy
	@project = Project.find(params[:id])
	@users=User.all
	@users.each do |a|
		pro_name = a.project_name
		pro_arr = a.project_name.split(", ")
                if pro_arr.count==1
                        pro_name.slice! @project.name
		elsif pro_arr.last.eql?(@project.name)
			pro_name.slice! ", "+@project.name
		else
			pro_name.slice! @project.name+", "
		end
		User.update(a.id, :project_name => pro_name)
	end

	@project.destroy

	respond_to do |format|
		format.html { redirect_to projects_url }
		format.json { head :no_content }
	end
end	

#-----------------

end
