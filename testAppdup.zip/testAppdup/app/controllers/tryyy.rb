m="noppur , njkdhjh, meena, jidji"
a="meena"
m.slice! a+", "
puts m
