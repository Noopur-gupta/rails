class AdminWorkController < ApplicationController

def assign_pro


end
end
