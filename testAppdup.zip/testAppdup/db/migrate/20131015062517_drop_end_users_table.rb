class DropEndUsersTable < ActiveRecord::Migration
  def up
drop_table:end_users
  end

  def down
  end
end
