# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TestApp::Application.config.secret_token = '6473cf2fc19464c9dbcac1e2be3d18f48b40dde0d35218a868a9b8fe36bebaac0769fbcd557dafa7bed7c1ec94778a3b68642afc5e283cac54b10cacc2177459'
