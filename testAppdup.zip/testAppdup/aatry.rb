a= "Noo"
a.split(",")
puts a
