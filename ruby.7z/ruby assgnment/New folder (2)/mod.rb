module Module_1
def Module_1.my
   puts "hi im a module"
 end
 end